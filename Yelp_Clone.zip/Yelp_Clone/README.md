<h1>Yelp_Clone</h1>
I made a clone of Yelp app but for study purpose such as API in general
<h1>User Manuel</h1>
It has two input fields and one button on the main page for user. First input field "Food" is to look up what kind food or restaurant user wants to look up, and second input field "Location" is for where the user wants to eat at. The button is a searching button, which will guide user into result pages where user can browse through the result.
<h1>Methodologies</h1>
Yelp Fusion: https://www.yelp.com/developers?country=US<br>
Autehntication<br>
Sending HTTP requests to Yelp Database<br>
Parsing Yelp Json feedbacks<br>
Dynamically creating views for the feedbacks<br>
<h1>Compliation</h1>
Run it with Android Studio, and the application works on Lolipop 5+ Android devices
<h1>What the application has</h1>
It has the name of restaurant as well as one image of their food.<br>
I could easily put the address, rating, price, and all other stuffs in it, 
because they have the same implementations as images and names, so I did not include since I got the idea.
