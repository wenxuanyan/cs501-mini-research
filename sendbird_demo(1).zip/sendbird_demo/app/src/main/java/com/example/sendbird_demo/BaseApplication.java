package com.example.sendbird_demo;

import android.app.Application;
import android.util.Log;


import com.sendbird.android.OpenChannel;
import com.sendbird.android.SendBird;
import com.sendbird.android.SendBirdException;
import com.sendbird.android.User;
import com.sendbird.android.handlers.InitResultHandler;
import com.sendbird.uikit.SendBirdUIKit;
import com.sendbird.uikit.adapter.SendBirdUIKitAdapter;
import com.sendbird.uikit.interfaces.UserInfo;

public class BaseApplication extends Application {
    String App_ID = "44E15C0D-8F8C-46E1-AE5E-746D63CB7619";
    String User_ID = "max0123";
    String User_Nickname = "Max";
    @Override
    public void onCreate() {
        super.onCreate();

        SendBirdUIKit.init(new SendBirdUIKitAdapter() {
            @Override
            public String getAppId() {
                return App_ID;  // Specify your Sendbird application ID.
            }

            @Override
            public String getAccessToken() {
                return "";
            }

            @Override
            public UserInfo getUserInfo() {
                return new UserInfo() {
                    @Override
                    public String getUserId() {
                        return User_ID;  // Specify your user ID.
                    }

                    @Override
                    public String getNickname() {
                        return User_Nickname;  // Specify your user nickname.
                    }

                    @Override
                    public String getProfileUrl() {
                        return "";
                    }
                };
            }

            @Override
            public InitResultHandler getInitResultHandler() {
                return new InitResultHandler() {
                    @Override
                    public void onMigrationStarted() {
                        // DB migration has started.
                    }

                    @Override
                    public void onInitFailed(SendBirdException e) {
                        // If DB migration fails, this method is called.
                    }

                    @Override
                    public void onInitSucceed() {
                        // If DB migration is successful, this method is called and you can proceed to the next step.
                        // In the sample app, the `LiveData` class notifies you on the initialization progress
                        // And observes the `MutableLiveData<InitState> initState` value in `SplashActivity()`.
                        // If successful, the `LoginActivity` screen
                        // Or the `HomeActivity` screen will show.
                    }
                };
            }
        }, this);

    }

    public void setUserId(String userId) {this.User_ID = userId;}

    public void setUserNickname(String userNickname){this.User_Nickname = userNickname;}

}


//        // When the useLocalCaching is set to false.
//        SendBird.init(App_ID, getApplicationContext(), false, new InitResultHandler() {
//            @Override public void onMigrationStarted() {
//                // This won't be called if useLocalCaching is set to false.
//            }
//            @Override public void onInitFailed(SendBirdException e) {
//                // This won't be called if useLocalCaching is set to false.
//            }
//            @Override public void onInitSucceed() {
//                Log.i("Application", "Called when initialization is completed.");
//            }
//        });
//
//        SendBird.connect(User_ID, new SendBird.ConnectHandler() {
//            @Override
//            public void onConnected(User user, SendBirdException e) {
//                if (e != null) {
//                    // Handle error.
//                }
//
//                // The user is connected to Sendbird server.
//            }
//        });
//
//        OpenChannel.createChannel(new OpenChannel.OpenChannelCreateHandler() {
//            @Override
//            public void onResult(OpenChannel openChannel, SendBirdException e) {
//                if (e != null) {
//                    // Handle error.
//                }
//
//                // An open channel is successfully created.
//                // Through the "openChannel" parameter of the onResult() callback method,
//                // you can get the open channel's data from the result object that Sendbird server has passed to the onResult().
//            }
//        });

// The CHANNEL_URL below can be retrieved using the openChannel.getUrl().
//        String Channel_URL = OpenChannel.getUrl();
//
//        OpenChannel.getChannel(CHANNEL_URL, new OpenChannel.OpenChannelGetHandler() {
//            @Override
//            public void onResult(OpenChannel openChannel, SendBirdException e) {
//                if (e != null) {
//                    // Handle error.
//                }

// Call the instance method of the result object in the "openChannel" parameter of the onResult() callback method.
//                openChannel.enter(new OpenChannel.OpenChannelEnterHandler() {
//                    @Override
//                    public void onResult(SendBirdException e) {
//                        if (e != null) {
//                            // Handle error.
//                        }
//
//                        // The current user successfully enters the open channel,
//                        // and can chat with other users in the channel by using APIs.
//                    }
//                });
      /*      }
        });*/
