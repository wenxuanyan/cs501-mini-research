package com.example.sendbird_demo;


import android.os.Bundle;

import com.sendbird.uikit.activities.ChannelListActivity;

public class MainActivity extends ChannelListActivity {


}