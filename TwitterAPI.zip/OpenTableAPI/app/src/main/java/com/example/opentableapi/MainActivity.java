package com.example.opentableapi;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class MainActivity extends AppCompatActivity {

    private EditText edtUser1;
    private EditText edtUser2;
    private Button btnSearchUser1;
    private Button btnSearchUser2;
    private Button btnMerge;
    private ListView lvResult;

    // Initialize lists that store two users' followings.
    private ArrayList<String> user1Following = new ArrayList<>();
    private ArrayList<String> user2Following = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);


        setContentView(R.layout.activity_main);

        edtUser1 = (EditText) findViewById(R.id.edtUser1);
        edtUser2 = (EditText) findViewById(R.id.edtUser2);
        btnSearchUser1 = (Button) findViewById(R.id.btnSearchUser1);
        btnSearchUser2 = (Button) findViewById(R.id.btnSearchUser2);
        btnMerge = (Button) findViewById(R.id.btnMerge);
        lvResult = (ListView) findViewById(R.id.lvResult);

        // First button generates the following list of user1
        btnSearchUser1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                searchFollowingRequestByUser(edtUser1.getText().toString(), user1Following);
            }
        });

        // Second button generates the following list of user2
        btnSearchUser2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                searchFollowingRequestByUser(edtUser2.getText().toString(), user2Following);
            }
        });

        // Third button compares the following list of two users and return accounts they both follow
        btnMerge.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ArrayList<String> common = followingCompare(user1Following, user2Following);
                ArrayAdapter arrayAdaptor = new ArrayAdapter(getApplicationContext(), android.R.layout.simple_list_item_1, common);
                lvResult.setAdapter(arrayAdaptor);
            }
        });
    }

    // Use Volley to make network request and retrieve data
    private void searchFollowingRequestByUser(String userName, ArrayList<String> followingList){
        // Generate URL based on the input username.
        String path = "https://api.twitter.com/2/users/by/username/" + userName;
        // Following request returns user information given the user name, we only need ID here.
        StringRequest followingRequest = new StringRequest(Request.Method.GET, path, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                try {
                    JSONObject result = new JSONObject(response);
                    String id = result.getJSONObject("data").getString("id");
                    // Use ID to retrieve user's following list
                    searchFollowingRequestById(id, followingList);
                    // Catch for the JSON parsing error
                } catch (JSONException e) {
                    Toast.makeText(MainActivity.this, e.getMessage(), Toast.LENGTH_LONG).show();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(MainActivity.this, "Not responding (Search ID)", Toast.LENGTH_LONG).show();
            }

        }){
            // Add authorization token to our request
            public Map<String, String> getHeaders(){
                HashMap<String, String> params = new HashMap<>();

                params.put("Authorization", "Bearer AAAAAAAAAAAAAAAAAAAAADpcbAEAAAAAHSn7%2BNKeGBspyjD%2Fft4TEKCqrro%3Dvr9oJ1uIII8CMyT4p6qjRFvkTPKetxSZ0R4yWZdFvdyMFdoO06");

                return params;
            }
        };
        // Put request into a request queue
        Volley.newRequestQueue(getApplicationContext()).add(followingRequest);
    }

    public void searchFollowingRequestById(String Id, ArrayList<String> followingList){
        // Generate URL based on the user's ID.
        String path = "https://api.twitter.com/2/users/" + Id + "/following";
        // Following request returns a list of user's following accounts given the user's ID.
        StringRequest followingRequest = new StringRequest(Request.Method.GET, path, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                try {
                    JSONObject result = new JSONObject(response);
                    JSONArray array = result.getJSONArray("data");
                    followingList.clear();
                    for (int i = 0; i < array.length(); i++){
                        followingList.add(array.getJSONObject(i).getString("name"));
                    }
                    //tvResult.setText(array.getJSONObject(0).getString("name"));
                    ArrayAdapter arrayAdaptor = new ArrayAdapter(getApplicationContext(), android.R.layout.simple_list_item_1, followingList);
                    lvResult.setAdapter(arrayAdaptor);
                } catch (JSONException e) {
                    Toast.makeText(MainActivity.this, e.getMessage(), Toast.LENGTH_LONG).show();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(MainActivity.this, "Not responding (Search Following)", Toast.LENGTH_LONG).show();
            }

        }){
            // Add authorization token to our request
            public Map<String, String> getHeaders(){
                HashMap<String, String> params = new HashMap<>();

                params.put("Authorization", "Bearer AAAAAAAAAAAAAAAAAAAAADpcbAEAAAAAHSn7%2BNKeGBspyjD%2Fft4TEKCqrro%3Dvr9oJ1uIII8CMyT4p6qjRFvkTPKetxSZ0R4yWZdFvdyMFdoO06");

                return params;
            }
        };
        // Put request into a request queue
        Volley.newRequestQueue(getApplicationContext()).add(followingRequest);
    }

    // Compare the two list and return common followings
    public ArrayList<String> followingCompare(ArrayList<String> list1, ArrayList<String> list2){
        ArrayList<String> common = new ArrayList<>();
        for (int i = 0; i < list1.size(); i ++) {
            if (list2.contains(list1.get(i))) {
                common.add(list1.get(i));
            }
        }
        return common;
    }
}