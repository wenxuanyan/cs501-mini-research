package com.example.sendbird_demo;


import com.sendbird.uikit.activities.ChannelListActivity;

public class MainActivity extends ChannelListActivity {
//Let the MainActivity inherits from the ChannelListActivity
// imported from the UIkit dependency. By this implementation,
// the application would have a chat application interface.

// If you’re going to inherit `ChannelListActivity`, don’t implement `setContentView()` in the activity.
}