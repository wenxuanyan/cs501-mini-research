package com.example.sendbird_demo;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.EditText;

import com.sendbird.uikit.SendBirdUIKit;
import com.sendbird.uikit.log.Logger;
import com.sendbird.uikit.widgets.WaitingDialog;

public class LoginActivity extends AppCompatActivity {

    @Override
    public void onCreate( Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_login);

        EditText etUserId = findViewById(R.id.etUserId);
        EditText etNickname = findViewById(R.id.etNickname);


        findViewById(R.id.btSignIn).setOnClickListener(v -> {
            String userId = etUserId.getText().toString();
            String userNickname = etNickname.getText().toString();
            if (userId.isEmpty() || userNickname.isEmpty()) {
                return;
            }

            //Will call the setter methods in the baseApplication class to set user’s credentials
            // ,kind of like fragment communication.
            ((BaseApplication)getApplication()).setUserId(userId);
            ((BaseApplication)getApplication()).setUserNickname(userNickname);

            //SendBirdUIKit.connect will establish connection to SendBird server with the information
            // provided in the SendBirdUIKitAdapter in the baseApplication class.
            SendBirdUIKit.connect((user, e) -> {
                if (e != null) {
                    return;
                }
            //If a connection is successfully built, the app will move to the mainAcitivity where the
                // chat interface is implemented
                Intent intent = new Intent(LoginActivity.this, MainActivity.class);
                startActivity(intent);
                finish();
            });
        });
    }
}

