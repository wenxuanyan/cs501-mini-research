<h1>SendBird_demo</h1>
This app is a demo for sendbird chat. Registered user could send messages to other registered users 
and create new chat channels with other registered users. 

<h1></h1>
You can login with the following user credentials:

ID: Max  NickName: Max
ID: David  NickName: David
ID: Lianghao  NickName: Lianghao
ID: Wanzhi  NickName: Wanzhi
ID: Daniel  NickName: Daniel
ID: Haowei  NickName: Haowei


